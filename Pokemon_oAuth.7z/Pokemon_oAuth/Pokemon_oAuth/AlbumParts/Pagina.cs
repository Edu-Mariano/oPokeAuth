﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.AlbumParts
{
    public class Pagina
    {
        public int QTD_Stickers;
        public string ID_Pagina;
        public string Image_Pagina;

        public Pagina()
        {
            string last_id = Serialization.Serialize.generateID("PG");
            int newId = int.Parse(last_id.Split('G')[1]);
            this.ID_Pagina = "PG" + (++newId);
        }
    }
}

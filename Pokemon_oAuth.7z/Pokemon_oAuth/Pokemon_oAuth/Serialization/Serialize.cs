﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Pokemon_oAuth.Serialization
{
    public class Serialize
    {
        public static String generateID(string type_reg)
        {
            string id = "";
            switch (type_reg)
            {
                case "PG":
                    string[] linespg = File.ReadAllLines("paginas.txt");
                    linespg.Last();
                    AlbumParts.Pagina jsonpg = JsonConvert.DeserializeObject<AlbumParts.Pagina>(linespg.Last());
                    id = jsonpg.ID_Pagina;
                    break;
                case "PK":
                    string[] linespk = File.ReadAllLines("pokemon.txt");
                    linespk.Last();
                    ClassRelationship.Pokemon jsonpk = JsonConvert.DeserializeObject<ClassRelationship.Pokemon>(linespk.Last());
                    id = jsonpk.Id_Pokemon;
                    break;
                case "TR":
                    string[] linestr = File.ReadAllLines("trainers.txt");
                    linestr.Last();
                    ClassRelationship.Trainer jsontr = JsonConvert.DeserializeObject<ClassRelationship.Trainer>(linestr.Last());
                    id = jsontr.Id_Trainer;
                    break;
                case "GR":
                    string[] linesgr = File.ReadAllLines("generation.txt");
                    linesgr.Last();
                    ClassRelationship.Generation jsongr = JsonConvert.DeserializeObject<ClassRelationship.Generation>(linesgr.Last());
                    id = jsongr.Id_Generation;
                    break;
                case "RN":
                    string[] linesrn = File.ReadAllLines("region.txt");
                    linesrn.Last();
                    ClassRelationship.Region jsonrn = JsonConvert.DeserializeObject<ClassRelationship.Region>(linesrn.Last());
                    id = jsonrn.Id_Region;
                    break;
            }
            return id;
        }
    }
}

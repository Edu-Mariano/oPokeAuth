using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.AlbumParts
{
    public class PaginaTrainers : Pagina 
    {
        public List<ClassRelationship.Trainer> Trainers;
    }
}
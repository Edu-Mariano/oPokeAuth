﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.ClassRelationship
{
    public class Generation
    {
        public string Id_Generation;
        public int Num_Generation;
        public string Nome_Generation;

    }
}

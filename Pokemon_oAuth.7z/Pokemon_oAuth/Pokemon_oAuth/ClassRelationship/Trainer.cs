﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.ClassRelationship
{
    public class Trainer
    {
        public string Id_Trainer;
        public string Nome_Trainer;
        public Region Regiao_Trainer;
        public Generation Geracao_Trainer;
    }
}

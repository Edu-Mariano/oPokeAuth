using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.AlbumParts
{
    public class PaginaRegion : Pagina 
    {
        public List<ClassRelationship.Region> Regions;
    }
}
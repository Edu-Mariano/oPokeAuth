﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.ClassRelationship
{
    public class Pokemon
    {
        public string Id_Pokemon;
        public string Nome_Pokemon;
        public Type Type_Pokemon;
        public int Numero_Pokemon;
        public Generation Geracao_Pokemon;
        public string Treinador_Pokemon;
        public string Habilidade_Pokemon;
        public string Descricao_Pokemon;
        public Region Regiao_Pokemon;
        public bool Status_Pokemon;
    }
}

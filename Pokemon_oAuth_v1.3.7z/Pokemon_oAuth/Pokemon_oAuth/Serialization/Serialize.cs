﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;

namespace Pokemon_oAuth.Serialization
{
    public class Serialize
    {
        private string ConnectString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=PokeoAuth.mdb";
        private static OleDbConnection conexao;
        private static OleDbCommand comando;
        public static OleDbDataReader reader;

        public Serialize()
        {
            conexao = new OleDbConnection(ConnectString);
            comando = new OleDbCommand();
        }

        /// <summary>
        /// Executa comandos de seleção e retorna o registro da propria
        /// </summary>
        /// <param name="query">comando necessario</param>
        /// <returns></returns>
        public static OleDbDataReader ReaderRegister(string query)
        {
            conexao.Open();
            comando = new OleDbCommand(query, conexao);
            reader = comando.ExecuteReader();
            conexao.Close();
            return reader;
        }

        public static void ExecuteQuery(string query)
        {
            conexao.Open();
            comando = new OleDbCommand(query, conexao);
            comando.ExecuteNonQuery();
            conexao.Close();
        }

        public Dictionary<int, ClassRelationship.Pokemon> getPokemons(List<string> ids)
        {
            Dictionary<int, ClassRelationship.Pokemon> lstObject = new Dictionary<int, ClassRelationship.Pokemon>();
            string query = "Select * From TB_POKEMON Where Num_Pokemon in " + ids.ToString();
            reader = ReaderRegister(query);
            while (reader.Read())
            {
                OleDbDataReader geracao = ReaderRegister("Select * from TB_GERACAO Where Id_Generation ='" + reader["Geracao_Pokemon"] + "' LIMIT 1");
                ClassRelationship.Generation generation = new ClassRelationship.Generation();
                generation.Id_Generation = (string)geracao["Id_Generation"];
                generation.Nome_Generation = (string)geracao["Nome_Generation"];
                generation.Num_Generation = (int)geracao["Num_Generation"];

                OleDbDataReader region = ReaderRegister("Select * from TB_REGION Where Id_Region ='" + reader["Regiao_Pokemon"] + "' LIMIT 1");
                ClassRelationship.Region region_poke = new ClassRelationship.Region();
                region_poke.Id_Region = (string)region["Id_Region"];
                region_poke.Nome_Region = (string)region["Nome_Region"];
                region_poke.Geracao_Region = generation;

                OleDbDataReader type = ReaderRegister("Select * from TB_Tipo Where Id_Type ='" + reader["Tipo_Pokemon"] + "' LIMIT 1");
                ClassRelationship.Type type_poke = new ClassRelationship.Type();
                type_poke.Id_Type = (string)type["Id_Type"];
                type_poke.Nome_Type = (string) type["Nome_Type"];

                ClassRelationship.Pokemon poke = new ClassRelationship.Pokemon();
                poke.Id_Pokemon = (string)reader["Id_Pokemon"];
                poke.Nome_Pokemon = (string)reader["Nome_Pokemon"];
                poke.Numero_Pokemon = (int)reader["Num_Pokemon"];
                poke.Regiao_Pokemon = region_poke;
                poke.Descricao_Pokemon = (string)reader["Desc_Pokemon"];
                poke.Geracao_Pokemon = generation;
                poke.Status_Pokemon = (string)reader["Status_Pokemon"] == "S";
                lstObject.Add(poke.Numero_Pokemon, poke);
            }
            return lstObject;
        }

        public Dictionary<string, ClassRelationship.Generation> getGeneration(){
            Dictionary<string, ClassRelationship.Generation> generation = new Dictionary<string, ClassRelationship.Generation>();
            return generation;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.ClassRelationship
{
    public class Type
    {
        public string Id_Type;
        public string Nome_Type;
        public Type Fraqueza_Type;
        public Type Ataque_Type;
        public string Descricao_Type;
    }
}

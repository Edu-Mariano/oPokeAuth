﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon_oAuth.ClassRelationship
{
    public class Region
    {
        public string Id_Region;
        public string Nome_Region;
        public Generation Geracao_Region;
    }
}
